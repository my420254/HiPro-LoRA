#!/usr/bin/env python3
"""One-off strict rerun: SST-5 Config A, HiPro-LoRA only, chosen beta.

This wrapper reuses the self-contained SST-5 strict script while redirecting
outputs to separate files so the published baseline CSVs remain untouched.
"""

import os
from pathlib import Path


THIS_FILE = Path(__file__).resolve()
BASE_SCRIPT = THIS_FILE.with_name("sst5_main_table2_strict.py")
SINGLE_SEED = os.environ.get("HIPRO_SINGLE_SEED", "").strip()
BETA = os.environ.get("HIPRO_BETA", "0.001").strip()
BETA_TAG = "beta" + BETA.replace(".", "p").replace("-", "m")
RUN_SUFFIX = f"_{BETA_TAG}" + (f"_seed{SINGLE_SEED}" if SINGLE_SEED else "")

src = BASE_SCRIPT.read_text()

old_results = (
    'MAIN_RESULTS_FILE = "/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/'
    'HiPro-loRA/table2_strict/results/sst5_main_table2_strict_results.csv"'
)
new_results = (
    'MAIN_RESULTS_FILE = "/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/'
    f'HiPro-loRA/table2_strict/results/sst5_ours_n1150_strict{RUN_SUFFIX}_results.csv"'
)
old_sensitivity = (
    'SENSITIVITY_FILE = "/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/'
    'HiPro-loRA/table2_strict/results/sst5_main_table2_strict_sensitivity_unused.csv"'
)
new_sensitivity = (
    'SENSITIVITY_FILE = "/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/'
    f'HiPro-loRA/table2_strict/results/sst5_ours_n1150_strict{RUN_SUFFIX}_sensitivity_unused.csv"'
)
old_artifacts = (
    'ARTIFACT_DIR = "/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/'
    'HiPro-loRA/table2_strict/artifacts/sst5/sst5_main_table2_strict"'
)
new_artifacts = (
    'ARTIFACT_DIR = "/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/'
    f'HiPro-loRA/table2_strict/artifacts/sst5/sst5_ours_n1150_strict{RUN_SUFFIX}"'
)

for needle in [old_results, old_sensitivity, old_artifacts, 'for N_SAMPLES in [2300, 1150]:']:
    if needle not in src:
        raise RuntimeError(f"Expected pattern not found in base script: {needle}")

src = src.replace(old_results, new_results)
src = src.replace(old_sensitivity, new_sensitivity)
src = src.replace(old_artifacts, new_artifacts)
src = src.replace('"eval_steps": 10, "memory_size": 200, "temperature": 0.15, "loss_weight": 0.0,',
                  f'"eval_steps": 10, "memory_size": 200, "temperature": 0.15, "loss_weight": {float(BETA)},')
src = src.replace('for N_SAMPLES in [2300, 1150]:', 'for N_SAMPLES in [1150]:')
if SINGLE_SEED:
    src = src.replace('RANDOM_SEEDS = [45, 123, 789, 2024, 1001]', f'RANDOM_SEEDS = [{int(SINGLE_SEED)}]')

start = src.index("EXPERIMENTS = [")
end = src.index("\n]\n\nSENS_TEMPS", start) + 3
ours_exp = '''EXPERIMENTS = [
    {"name": "LoRA-Ours-beta''' + BETA + '''", "method": "peft", "loss_type": "original",
     "use_class_weight": True, "peft_type": "lora", "hsp": True, "memory_bank": True},
]'''
src = src[:start] + ours_exp + src[end:]

exec_globals = {"__name__": "__main__", "__file__": str(BASE_SCRIPT)}
exec(compile(src, str(THIS_FILE), "exec"), exec_globals)
