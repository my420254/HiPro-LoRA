This directory contains the ECML PKDD 2026 camera-ready source files
for submission #572.

Main LaTeX file:

  main.tex

Required style and support files:

  llncs.cls
  splncs04.bst
  figures/

Figures included in paper order:

  figures/fig1_framework.pdf
  figures/fig2_gate.pdf
  figures/fig3_llm.pdf
  figures/fig4_efficiency.pdf
  figures/fig5_sensitivity.pdf

The expected compile command is:

  pdflatex main.tex

The final source archive should be named 572-source.zip.
