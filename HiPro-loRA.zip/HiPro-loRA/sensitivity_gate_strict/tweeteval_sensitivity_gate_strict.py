#!/usr/bin/env python3
"""Run all TweetEval strict sensitivity/gate scripts without changing internals."""

import os
import subprocess
import sys
from pathlib import Path


MAIN_CODE_DIR = Path("/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode")
BASE_DIR = MAIN_CODE_DIR / "HiPro-loRA" / "sensitivity_gate_strict"
SCRIPT_DIR = BASE_DIR / "scripts"

SCRIPTS = [
    "tweeteval_mem_tw_configB_strict.py",
    "tweeteval_temp_lw_configB_strict.py",
]


def main():
    env = os.environ.copy()
    env.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
    env.setdefault("TOKENIZERS_PARALLELISM", "false")
    for name in SCRIPTS:
        script = SCRIPT_DIR / name
        print(f"[TweetEval] start {script}", flush=True)
        subprocess.run([sys.executable, str(script)], cwd=str(MAIN_CODE_DIR), env=env, check=True)
        print(f"[TweetEval] done  {script}", flush=True)


if __name__ == "__main__":
    main()
