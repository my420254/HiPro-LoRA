import json
import os
import subprocess
import sys
import time
from collections import deque
from dataclasses import dataclass, asdict
from pathlib import Path


BASE_DIR = Path("/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/HiPro-loRA/sensitivity_gate_strict/gate_table2_aligned")
SCRIPT_DIR = BASE_DIR / "scripts"
LOG_DIR = BASE_DIR / "logs"
STATE_FILE = BASE_DIR / "runner_state.json"


@dataclass
class Task:
    dataset_key: str
    dataset_name: str
    script: str
    n_samples: int
    seed: int


DATASETS = [
    ("smp2020", "SMP2020", "smp2020_gate_table2_aligned.py", 1000, [123, 789, 2024, 1001, 45]),
    ("sst5", "SST-5", "sst5_gate_table2_aligned.py", 1150, [45, 123, 789, 2024, 1001]),
    ("tweeteval", "TweetEval", "tweeteval_gate_table2_aligned.py", 1000, [45, 123, 789, 2024, 1001]),
]


def parse_gpus():
    raw = os.environ.get("HIPRO_GATE_GPUS", "2,3")
    return [gpu.strip() for gpu in raw.split(",") if gpu.strip()]


def parse_gpu_slots(gpus):
    raw = os.environ.get("HIPRO_GATE_GPU_SLOTS", "")
    if not raw:
        slots_per_gpu = int(os.environ.get("HIPRO_GATE_SLOTS_PER_GPU", "3"))
        return {gpu: slots_per_gpu for gpu in gpus}
    slots = {}
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        gpu, cap = item.split(":", 1)
        slots[gpu.strip()] = int(cap.strip())
    return {gpu: slots.get(gpu, 0) for gpu in gpus}


def parse_csv_filter(name, cast=str):
    raw = os.environ.get(name, "").strip()
    if not raw:
        return None
    return {cast(item.strip()) for item in raw.split(",") if item.strip()}


def make_tasks():
    dataset_filter = parse_csv_filter("HIPRO_GATE_DATASETS", str)
    seed_filter = parse_csv_filter("HIPRO_GATE_SEEDS", int)
    tasks = []
    for dataset_key, dataset_name, script, n_samples, seeds in DATASETS:
        if dataset_filter and dataset_key not in dataset_filter and dataset_name not in dataset_filter:
            continue
        for seed in seeds:
            if seed_filter and seed not in seed_filter:
                continue
            tasks.append(Task(dataset_key, dataset_name, str(SCRIPT_DIR / script), n_samples, seed))
    return deque(tasks)


def write_state(pending, running, completed, failed):
    state = {
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "pending": [asdict(t) for t in pending],
        "running": [
            {
                "task": asdict(item["task"]),
                "gpu": item["gpu"],
                "pid": item["process"].pid,
                "log": str(item["log_path"]),
                "started_at": item["started_at"],
            }
            for item in running
        ],
        "completed": completed,
        "failed": failed,
    }
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2))


def launch(task, gpu):
    env = os.environ.copy()
    env.update(
        {
            "CUDA_VISIBLE_DEVICES": str(gpu),
            "HIPRO_GATE_N": str(task.n_samples),
            "HIPRO_GATE_SEED": str(task.seed),
            "HIPRO_GATE_METHOD": "LoRA-Ours",
            "HIPRO_GATE_SAVE_VIZ": "0",
            "HF_ENDPOINT": os.environ.get("HF_ENDPOINT", "https://hf-mirror.com"),
            "TOKENIZERS_PARALLELISM": "false",
            "PYTHONHASHSEED": str(task.seed),
            "CUBLAS_WORKSPACE_CONFIG": os.environ.get("CUBLAS_WORKSPACE_CONFIG", ":4096:8"),
            "NVIDIA_TF32_OVERRIDE": os.environ.get("NVIDIA_TF32_OVERRIDE", "0"),
        }
    )
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOG_DIR / f"{task.dataset_key}_N{task.n_samples}_seed{task.seed}_gpu{gpu}.log"
    log_fh = log_path.open("w")
    process = subprocess.Popen(
        [sys.executable, task.script],
        cwd=str(BASE_DIR),
        env=env,
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return {
        "task": task,
        "gpu": str(gpu),
        "process": process,
        "log_fh": log_fh,
        "log_path": log_path,
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def main():
    gpus = parse_gpus()
    gpu_slots = parse_gpu_slots(gpus)
    max_running = sum(gpu_slots.values())
    pending = make_tasks()
    running = []
    completed = []
    failed = []

    print(f"[runner] tasks={len(pending)} gpu_slots={gpu_slots} max_running={max_running}", flush=True)
    while pending or running:
        while pending and len(running) < max_running:
            counts = {gpu: sum(1 for item in running if item["gpu"] == gpu) for gpu in gpus}
            available = [gpu for gpu in gpus if counts[gpu] < gpu_slots[gpu]]
            if not available:
                break
            gpu = min(available, key=lambda x: counts[x])
            task = pending.popleft()
            item = launch(task, gpu)
            running.append(item)
            print(f"[runner] start {task.dataset_name} N={task.n_samples} seed={task.seed} on GPU{gpu} pid={item['process'].pid}", flush=True)

        for item in list(running):
            rc = item["process"].poll()
            if rc is None:
                continue
            item["log_fh"].close()
            running.remove(item)
            task = item["task"]
            record = {
                "dataset": task.dataset_name,
                "n_samples": task.n_samples,
                "seed": task.seed,
                "gpu": item["gpu"],
                "returncode": rc,
                "log": str(item["log_path"]),
            }
            if rc == 0:
                completed.append(record)
                print(f"[runner] done {task.dataset_name} N={task.n_samples} seed={task.seed} GPU{item['gpu']}", flush=True)
            else:
                failed.append(record)
                print(f"[runner] FAIL {task.dataset_name} N={task.n_samples} seed={task.seed} GPU{item['gpu']} rc={rc} log={item['log_path']}", flush=True)

        write_state(pending, running, completed, failed)
        if pending or running:
            time.sleep(5)

    print(f"[runner] completed={len(completed)} failed={len(failed)}", flush=True)
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
