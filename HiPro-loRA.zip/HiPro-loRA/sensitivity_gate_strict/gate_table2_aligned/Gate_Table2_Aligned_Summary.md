# Table2 对齐版 Gate 轨迹汇总

本目录只用于论文 gate figure 的 AHSP gate 标量 `sigma(lambda)` 轨迹收集。三份运行脚本从 `table2_strict` 的 main 脚本复制，只改输出目录、只筛选 `LoRA-Ours` 的 Config A，并新增 gate callback；没有改动 Table 2 原始脚本和原始结果。

精度不作为本 gate 实验输出结论；内部 sanity CSV 保存在 `results/gate_table2_aligned_metrics_internal.csv`，这里只汇总 gate 参数。

## Config A

| Dataset | N | Seeds | sigma init | sigma final | delta | mean min | mean max |
|---|---:|---:|---:|---:|---:|---:|---:|
| SMP2020 | 1000 | 5 | 0.1192 ± 0.0000 | 0.1224 ± 0.0018 | 0.0032 ± 0.0018 | 0.1190 | 0.1242 |
| SST-5 | 1150 | 5 | 0.1192 ± 0.0000 | 0.1229 ± 0.0017 | 0.0037 ± 0.0017 | 0.1192 | 0.1256 |
| TweetEval | 1000 | 5 | 0.0110 ± 0.0000 | 0.0120 ± 0.0003 | 0.0010 ± 0.0003 | 0.0110 | 0.0125 |

## 输出文件

- `results/gate_table2_aligned_gate_trace_raw.csv`: 每个 seed 的原始 gate 记录。
- `results/gate_table2_aligned_curve_by_index.csv`: 按 checkpoint index 对齐后的均值和标准差，可直接画论文 gate figure。
- `results/gate_table2_aligned_final_by_seed.csv`: 每个 seed 的 init/final/min/max。
- `results/gate_table2_aligned_gate_summary.csv`: 上表的机器可读版本。
- `figures/figure_gate_table2_aligned.pdf` 和 `.png`: 自动生成的 gate 曲线图。

## 解释

这个实验回答的是 gate 是否真的在训练中动态调整，而不是重新证明 Table 2 精度。若复跑精度有随机漂移，正文应引用 Table 2 的主结果；论文 gate figure 只引用这里的 `sigma(lambda)` 轨迹均值和标准差。
