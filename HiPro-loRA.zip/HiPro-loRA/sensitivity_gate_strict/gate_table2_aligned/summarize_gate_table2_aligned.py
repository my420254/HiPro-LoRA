import os
from pathlib import Path

import numpy as np
import pandas as pd


BASE_DIR = Path("/home/zmy/a-start/HiPro-LoRA/HiPro-LoRA/mainCode/HiPro-loRA/sensitivity_gate_strict/gate_table2_aligned")
RESULTS_DIR = BASE_DIR / "results"
GATE_LOG_DIR = BASE_DIR / "gate_logs"
FIGURE_DIR = BASE_DIR / "figures"
SUMMARY_MD = BASE_DIR / "Gate_Table2_Aligned_Summary.md"


def fmt_mean_std(mean, std, digits=4):
    if pd.isna(mean):
        return ""
    if pd.isna(std):
        return f"{mean:.{digits}f}"
    return f"{mean:.{digits}f} ± {std:.{digits}f}"


def load_metrics():
    files = sorted(
        p
        for p in RESULTS_DIR.glob("*_gate_table2_aligned_N*_seed*.csv")
        if "sensitivity" not in p.name and not p.name.startswith("gate_table2_aligned_")
    )
    frames = []
    for path in files:
        try:
            df = pd.read_csv(path)
        except pd.errors.EmptyDataError:
            continue
        df["source_file"] = str(path)
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    combined = pd.concat(frames, ignore_index=True)
    combined.to_csv(RESULTS_DIR / "gate_table2_aligned_metrics_internal.csv", index=False)
    return combined


def load_gate_logs():
    frames = []
    for path in sorted(GATE_LOG_DIR.glob("*/*_gate.csv")):
        try:
            df = pd.read_csv(path)
        except pd.errors.EmptyDataError:
            continue
        if df.empty:
            continue
        df["source_file"] = str(path)
        frames.append(df)
    if not frames:
        raw_trace = RESULTS_DIR / "gate_table2_aligned_gate_trace_raw.csv"
        if raw_trace.exists():
            return pd.read_csv(raw_trace)
        return pd.DataFrame()
    combined = pd.concat(frames, ignore_index=True)
    combined.to_csv(RESULTS_DIR / "gate_table2_aligned_gate_trace_raw.csv", index=False)
    return combined


def make_curve(trace):
    if trace.empty:
        return pd.DataFrame()
    curve_parts = []
    for _, df in trace.groupby(["Dataset", "N", "Seed", "source_file"], dropna=False):
        ordered = df[df["phase"].isin(["train_begin", "eval"])].copy()
        ordered = ordered.dropna(subset=["gate_sigmoid"]).sort_values(["step", "phase"])
        ordered["trace_index"] = np.arange(len(ordered))
        curve_parts.append(ordered)
    if not curve_parts:
        return pd.DataFrame()
    indexed = pd.concat(curve_parts, ignore_index=True)
    curve = (
        indexed.groupby(["Dataset", "N", "trace_index"], as_index=False)
        .agg(
            gate_mean=("gate_sigmoid", "mean"),
            gate_std=("gate_sigmoid", "std"),
            gate_min=("gate_sigmoid", "min"),
            gate_max=("gate_sigmoid", "max"),
            mean_step=("step", "mean"),
            mean_epoch=("epoch", "mean"),
            n_seeds=("Seed", "nunique"),
        )
        .sort_values(["Dataset", "N", "trace_index"])
    )
    curve.to_csv(RESULTS_DIR / "gate_table2_aligned_curve_by_index.csv", index=False)
    return curve


def make_final_summary(trace):
    rows = []
    for (dataset, n_samples, seed, source_file), df in trace.groupby(["Dataset", "N", "Seed", "source_file"], dropna=False):
        df = df.dropna(subset=["gate_sigmoid"]).sort_values(["step", "phase"])
        if df.empty:
            continue
        begin = df[df["phase"] == "train_begin"]
        final = df[df["phase"] == "best_model_after_predict"]
        if final.empty:
            final = df.tail(1)
        rows.append(
            {
                "Dataset": dataset,
                "N": int(n_samples),
                "Seed": int(seed),
                "Gate_Init": float(begin.iloc[0]["gate_sigmoid"]) if not begin.empty else np.nan,
                "Gate_Final": float(final.iloc[-1]["gate_sigmoid"]),
                "Gate_Delta": float(final.iloc[-1]["gate_sigmoid"] - begin.iloc[0]["gate_sigmoid"]) if not begin.empty else np.nan,
                "Gate_Min": float(df["gate_sigmoid"].min()),
                "Gate_Max": float(df["gate_sigmoid"].max()),
                "Log_File": source_file,
            }
        )
    per_seed = pd.DataFrame(rows)
    if per_seed.empty:
        return per_seed, pd.DataFrame()
    per_seed.to_csv(RESULTS_DIR / "gate_table2_aligned_final_by_seed.csv", index=False)
    summary = (
        per_seed.groupby(["Dataset", "N"], as_index=False)
        .agg(
            Seeds=("Seed", "nunique"),
            Gate_Init_Mean=("Gate_Init", "mean"),
            Gate_Init_Std=("Gate_Init", "std"),
            Gate_Final_Mean=("Gate_Final", "mean"),
            Gate_Final_Std=("Gate_Final", "std"),
            Gate_Delta_Mean=("Gate_Delta", "mean"),
            Gate_Delta_Std=("Gate_Delta", "std"),
            Gate_Min_Mean=("Gate_Min", "mean"),
            Gate_Max_Mean=("Gate_Max", "mean"),
        )
        .sort_values(["Dataset", "N"])
    )
    summary.to_csv(RESULTS_DIR / "gate_table2_aligned_gate_summary.csv", index=False)
    return per_seed, summary


def plot_curve(curve):
    if curve.empty:
        return []
    try:
        from matplotlib import font_manager
        import matplotlib.pyplot as plt
    except Exception:
        return []
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    paths = []

    local_times = BASE_DIR.parents[1] / "Times_New_Roman.ttf"
    if local_times.exists():
        font_manager.fontManager.addfont(str(local_times))
    for font_path in [
        Path("/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf"),
        Path("/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf"),
    ]:
        if font_path.exists():
            font_manager.fontManager.addfont(str(font_path))

    plt.rcParams.update(
        {
            "font.family": "Liberation Serif",
            "mathtext.fontset": "dejavuserif",
            "axes.unicode_minus": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    paper_curve = curve[curve["n_seeds"] == 5].copy()
    if paper_curve.empty:
        paper_curve = curve.copy()

    dataset_order = ["SMP2020", "SST-5", "TweetEval"]
    titles = {
        "SMP2020": "(a) SMP2020 (N=1000)",
        "SST-5": "(b) SST-5 (N=1150)",
        "TweetEval": "(c) TweetEval (N=1000)",
    }
    colors = {
        "SMP2020": "#e41a1c",
        "SST-5": "#377eb8",
        "TweetEval": "#4daf4a",
    }

    fig, axes = plt.subplots(1, 3, figsize=(54.117, 21.153))
    for ax, dataset in zip(axes, dataset_order):
        df = paper_curve[paper_curve["Dataset"] == dataset].sort_values("mean_epoch")
        if df.empty:
            ax.set_visible(False)
            continue
        x = df["mean_epoch"].to_numpy()
        y = df["gate_mean"].to_numpy()
        std = df["gate_std"].fillna(0.0).to_numpy()
        color = colors[dataset]

        ax.fill_between(x, y - std, y + std, color=color, alpha=0.2, linewidth=0)
        ax.plot(x, y, color=color, linewidth=5.5, label=dataset)

        ymin = float((y - std).min())
        ymax = float((y + std).max())
        pad = max((ymax - ymin) * 0.25, 0.00035)
        ax.set_ylim(ymin - pad, ymax + pad)
        ax.set_xlim(0, 15)
        ax.set_title(titles[dataset], fontsize=64, fontweight="bold", pad=28)
        ax.set_xlabel("Training Epoch", fontsize=72, fontweight="bold", labelpad=22)
        ax.grid(True, linestyle="--", linewidth=2.5, alpha=0.6)
        ax.tick_params(axis="both", labelsize=42, width=2.5, length=10)
        for spine in ax.spines.values():
            spine.set_linewidth(2.8)

    axes[0].set_ylabel(r"Gating Scalar $\sigma(\lambda)$", fontsize=72, fontweight="bold", labelpad=28)

    handles = [
        plt.Line2D([0], [0], color=colors[dataset], lw=8, label=dataset)
        for dataset in dataset_order
    ]
    fig.legend(
        handles=handles,
        loc="lower center",
        ncol=3,
        frameon=False,
        fontsize=72,
        handlelength=1.8,
        handletextpad=1.2,
        columnspacing=4.0,
    )
    fig.subplots_adjust(left=0.055, right=0.995, bottom=0.335, top=0.93, wspace=0.11)

    for basename in ["figure_gate_table2_aligned", "figure7_gatel"]:
        for suffix in ["pdf", "png"]:
            path = FIGURE_DIR / f"{basename}.{suffix}"
            fig.savefig(path, dpi=300)
            paths.append(path)
    plt.close(fig)
    return paths


def write_markdown(summary, per_seed, curve, figure_paths):
    lines = [
        "# Table2 对齐版 Gate 轨迹汇总",
        "",
        "本目录只用于论文 gate figure 的 AHSP gate 标量 `sigma(lambda)` 轨迹收集。三份运行脚本从 `table2_strict` 的 main 脚本复制，只改输出目录、只筛选 `LoRA-Ours` 的 Config A，并新增 gate callback；没有改动 Table 2 原始脚本和原始结果。",
        "",
        "精度不作为本 gate 实验输出结论；内部 sanity CSV 保存在 `results/gate_table2_aligned_metrics_internal.csv`，这里只汇总 gate 参数。",
        "",
        "## Config A",
        "",
        "| Dataset | N | Seeds | sigma init | sigma final | delta | mean min | mean max |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for _, row in summary.iterrows():
        lines.append(
            "| {Dataset} | {N} | {Seeds} | {init} | {final} | {delta} | {gmin:.4f} | {gmax:.4f} |".format(
                Dataset=row["Dataset"],
                N=int(row["N"]),
                Seeds=int(row["Seeds"]),
                init=fmt_mean_std(row["Gate_Init_Mean"], row["Gate_Init_Std"]),
                final=fmt_mean_std(row["Gate_Final_Mean"], row["Gate_Final_Std"]),
                delta=fmt_mean_std(row["Gate_Delta_Mean"], row["Gate_Delta_Std"]),
                gmin=row["Gate_Min_Mean"],
                gmax=row["Gate_Max_Mean"],
            )
        )
    lines += [
        "",
        "## 输出文件",
        "",
        "- `results/gate_table2_aligned_gate_trace_raw.csv`: 每个 seed 的原始 gate 记录。",
        "- `results/gate_table2_aligned_curve_by_index.csv`: 按 checkpoint index 对齐后的均值和标准差，可直接画论文 gate figure。",
        "- `results/gate_table2_aligned_final_by_seed.csv`: 每个 seed 的 init/final/min/max。",
        "- `results/gate_table2_aligned_gate_summary.csv`: 上表的机器可读版本。",
    ]
    if figure_paths:
        lines.append("- `figures/figure_gate_table2_aligned.pdf` 和 `.png`: 自动生成的 gate 曲线图。")
    lines += [
        "",
        "## 解释",
        "",
        "这个实验回答的是 gate 是否真的在训练中动态调整，而不是重新证明 Table 2 精度。若复跑精度有随机漂移，正文应引用 Table 2 的主结果；论文 gate figure 只引用这里的 `sigma(lambda)` 轨迹均值和标准差。",
        "",
    ]
    SUMMARY_MD.write_text("\n".join(lines), encoding="utf-8")


def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    metrics = load_metrics()
    trace = load_gate_logs()
    if trace.empty:
        raise SystemExit("No gate logs found.")
    curve = make_curve(trace)
    per_seed, summary = make_final_summary(trace)
    make_figures = os.environ.get("HIPRO_GATE_MAKE_FIGURES", "0") == "1"
    write_local_md = os.environ.get("HIPRO_GATE_WRITE_LOCAL_MD", "0") == "1"
    figure_paths = plot_curve(curve) if make_figures else []
    if write_local_md:
        write_markdown(summary, per_seed, curve, figure_paths)
    print(f"[summary] metrics_rows={len(metrics)} trace_rows={len(trace)}")
    print(f"[summary] wrote CSV files under {RESULTS_DIR}")
    if make_figures:
        print(f"[summary] wrote figures under {FIGURE_DIR}")
    if write_local_md:
        print(f"[summary] wrote {SUMMARY_MD}")


if __name__ == "__main__":
    main()
