#!/usr/bin/env python3
"""Run Table2-aligned gate collection and summarize its CSV outputs."""

import os
import subprocess
import sys
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parents[1]
MAIN_CODE_DIR = PROJECT_DIR.parent
GATE_DIR = PROJECT_DIR / "sensitivity_gate_strict" / "gate_table2_aligned"


def main():
    env = os.environ.copy()
    env.setdefault("HIPRO_GATE_GPUS", os.environ.get("HIPRO_RUN_GPUS", "0,1,2,3"))
    env.setdefault("HIPRO_GATE_GPU_SLOTS", os.environ.get("HIPRO_RUN_GPU_SLOTS", "0:2,1:2,2:3,3:3"))
    env.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
    env.setdefault("TOKENIZERS_PARALLELISM", "false")
    env.setdefault("NVIDIA_TF32_OVERRIDE", "0")
    env.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    env.setdefault("PYTHONUNBUFFERED", "1")

    runner = GATE_DIR / "run_gate_table2_aligned.py"
    summarizer = GATE_DIR / "summarize_gate_table2_aligned.py"
    print(f"[gate_table2_aligned] run {runner}", flush=True)
    subprocess.run([sys.executable, str(runner)], cwd=str(MAIN_CODE_DIR), env=env, check=True)
    print(f"[gate_table2_aligned] summarize {summarizer}", flush=True)
    subprocess.run([sys.executable, str(summarizer)], cwd=str(MAIN_CODE_DIR), env=env, check=True)


if __name__ == "__main__":
    main()
