#!/usr/bin/env python3
"""Run strict sensitivity/gate dataset entry scripts."""

from pathlib import Path

from _runner import PROJECT_DIR, Task, run_tasks


SCRIPTS = [
    ("smp2020_sensitivity_gate", "sensitivity_gate_strict/smp2020_sensitivity_gate_strict.py"),
    ("sst5_sensitivity_gate", "sensitivity_gate_strict/sst5_sensitivity_gate_strict.py"),
    ("tweeteval_sensitivity_gate", "sensitivity_gate_strict/tweeteval_sensitivity_gate_strict.py"),
]


def main():
    tasks = [Task(name, PROJECT_DIR / Path(script)) for name, script in SCRIPTS]
    run_tasks(tasks, "sensitivity_gate_strict")


if __name__ == "__main__":
    main()
